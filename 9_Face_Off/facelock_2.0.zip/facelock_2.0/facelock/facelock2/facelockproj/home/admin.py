from django.contrib import admin
from home.models import Post, Friend

admin.site.register(Post)
admin.site.register(Friend)
