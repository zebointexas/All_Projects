import robin_stocks as r
import time
import queue

r.login('zeboxiong.texas@gmail.com','Mzktin890890!')

my_stocks = r.build_holdings()


#print(key, value['price'], int(time.time()))

for key,value in my_stocks.items():
    if key == 'TSLA' :
        key_z = key
        price_z = value['price']
        time_z = int(time.time())

print(key_z, price_z, time_z)

t = [];

with open("Output.txt", "a") as text_file:
    print(key_z, price_z, time_z, file=text_file)


with open("Output.txt", "a") as text_file:
    print(key_z, price_z, time_z, file=text_file)


count = 0
while (count < 3):
   t.append(int(time.time()))
   count = count + 1
   time.sleep(1)
print(t)
print(t[1])



###     dict = {'Name': 'Zara', 'Age': 7, 'Class': 'First'}
###     dict['Age'] = 8
###     dict['School'] = "DPS School"
###     print("dict['Age']: ", dict['Age'])
###     print("dict['School']: ", dict['School'])















## optionData = r.find_options_for_list_of_stocks_by_expiration_date(['tsla','sqqq'],
##              expirationDate='2019-03-28',optionType='call')


positions_data = r.get_current_positions()


TSLAData = [item for item in positions_data if r.get_name_by_url(item['instrument']) == r.get_name_by_symbol('TSLA')][0]
sellQuantity = float(TSLAData['quantity'])/2.0

# print(sellQuantity);


url = 'https://api.robinhood.com/options/instruments/'
payload = { 'type' : 'call'}
zebo = r.request_get(url,'regular',payload)

# print(zebo['previous'])




# Where is MySQL: /usr/local/mysql/bin/mysql
# ./mysql -u root

# brew services start mysql



CREATE TABLE real_time_price(
    time_in_second int,
    real_time_price float,
    PRIMARY KEY ( time_in_second )
);