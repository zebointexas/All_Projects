import sqlite3
conn = sqlite3.connect('robin_zebo.db')

c = conn.cursor()

print(c.connection)

# Create table
# c.execute('''CREATE TABLE stocks  (date text, trans text, symbol text, qty real, price real)''')

# Insert a row of data
c.execute("INSERT INTO real_time_price VALUES (123,89928347234)")

# Save (commit) the changes
conn.commit()

# We can also close the connection if we are done with it.
# Just be sure any changes have been committed or they will be lost.
conn.close()