import robin_stocks as r
import time
import datetime

now = datetime.datetime.now()

filename = "Output_" + str(now.year) + str(now.month) + str(now.day) + ".txt"

r.login('zeboxiong.texas@gmail.com','Mzktin890890!')

count = 0

while (count<600):

    my_stocks = r.build_holdings()

    for key, value in my_stocks.items():
        if key == 'SQQQ':
            key_z = key
            price_z = value['price']
            time_z = datetime.datetime.now()

    with open(filename , "a") as text_file:
        print(key_z, ' - ', price_z, ' - ',  time_z, file=text_file)

    print(count)
    count = count + 1
    time.sleep(1)




